package mod13;
import mod13.Pessoa;
import mod13.PessoaFisica;
import mod13.PessoaJuridica;
public class programa {
	public static void main(String[] args) {
        pessoaJurídica pessoaJurídica = new pessoaJurídica("Empresa XYZ", "12345678901234");
        pessoaFisica pessoaFisica = new pessoaFisica("João", "123.456.789-01");

        realizarAcaoParaPessoa(pessoaJurídica);
        realizarAcaoParaPessoa(pessoaFisica);
    }

    public static void realizarAcaoParaPessoa(Pessoa pessoa) {
        pessoa.realizarAcao();
    }
}
