package mod13;

public class pessoaFisica extends Pessoa {
    private String cpf;

    public pessoaFisica(String nome, String cpf) {
        super(nome);
        this.cpf = cpf;
    }

    public String getCpf() {
        return cpf;
    }

   
    public void realizarAcao() {
        System.out.println("Ação realizada por Pessoa Física");
    }

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
    
}
