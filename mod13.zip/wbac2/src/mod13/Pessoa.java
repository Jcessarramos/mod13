package mod13;

  public abstract class Pessoa {
	    public String nome;

	    public Pessoa(String nome) {
	        this.nome = nome;
	    }

	    public String getNome() {
	        return nome;
	    }

	    public abstract void realizarAcao();

		public void setNome(String nome) {
			this.nome = nome;
		}
	    
	}

